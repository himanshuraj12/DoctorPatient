package com.Hraj.doctorpatientplatform.entity;

public enum City {
    DELHI, NOIDA, FARIDABAD
}
