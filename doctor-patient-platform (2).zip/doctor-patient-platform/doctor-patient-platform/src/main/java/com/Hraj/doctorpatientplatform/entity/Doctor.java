package com.Hraj.doctorpatientplatform.entity;

import javax.persistence.*;

@Entity
public class Doctor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String city;
    private String email;
    private String phoneNumber;

    @Enumerated(EnumType.STRING)
    private SpecialityType specialityEnum;

    @ManyToOne
    @JoinColumn(name = "speciality_id")
    private Speciality speciality;

    // Default constructor
    public Doctor() {
    }

    // Constructor with parameters
    public Doctor(String name, String city, String email, String phoneNumber, SpecialityType specialityEnum) {
        this.name = name;
        this.city = city;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.specialityEnum = specialityEnum;
    }

    // Getters and setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public SpecialityType getSpecialityEnum() {
        return specialityEnum;
    }

    public void setSpecialityEnum(SpecialityType specialityEnum) {
        this.specialityEnum = specialityEnum;
    }

    public Speciality getSpeciality() {
        return speciality;
    }

    public void setSpeciality(Speciality speciality) {
        this.speciality = speciality;
    }
}
