package com.Hraj.doctorpatientplatform.service;

import com.Hraj.doctorpatientplatform.entity.Doctor;
import com.Hraj.doctorpatientplatform.entity.Patient;
import com.Hraj.doctorpatientplatform.entity.Speciality;
import com.Hraj.doctorpatientplatform.repository.DoctorRepository;
import com.Hraj.doctorpatientplatform.repository.PatientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class DoctorSuggestionService {

    @Autowired
    private PatientRepository patientRepository;

    @Autowired
    private DoctorRepository doctorRepository;

    public List<Doctor> suggestDoctors(Long patientId) {
        // Retrieve patient information from the database
        Patient patient = patientRepository.findById(patientId).orElse(null);
        if (patient == null) {
            // Handle patient not found scenario
            return null;
        }

        // Extract patient's city and speciality
        String patientCity = patient.getCity();
        Speciality patientSpeciality = patient.getSpeciality();

        // Check if patient's city is within the supported locations
        if (!isValidCity(patientCity)) {
            return Collections.singletonList(new Doctor("We are still waiting to expand to your location", "", "", "", null, null));
        }

        // Query the doctor repository to find doctors matching the criteria
        List<Doctor> suggestedDoctors = DoctorRepository.findByCityAndSpecialityType(patientCity, patientSpeciality.getType());
        // Filter doctors based on the patient's speciality
        suggestedDoctors = suggestedDoctors.stream()
                .filter(doctor -> doctor.getSpecialityEnum() != null && doctor.getSpecialityEnum().equals(patientSpeciality.getType()))
                .collect(Collectors.toList());

        if (suggestedDoctors.isEmpty()) {
            return Collections.singletonList(new Doctor("There isn't any doctor present at your location for your symptom", "", "", "", null, null));
        }

        return suggestedDoctors;
    }

    private boolean isValidCity(String city) {
        return List.of("Delhi", "Noida", "Faridabad").contains(city);
    }
}
