package com.Hraj.doctorpatientplatform.entity;

public enum Priority {
    LOW,
    MEDIUM,
    HIGH
}
