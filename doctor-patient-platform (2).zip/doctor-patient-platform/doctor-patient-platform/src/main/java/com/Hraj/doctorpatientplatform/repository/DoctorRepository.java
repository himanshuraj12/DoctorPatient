package com.Hraj.doctorpatientplatform.repository;

import com.Hraj.doctorpatientplatform.entity.Doctor;
import com.Hraj.doctorpatientplatform.entity.Speciality;
import com.Hraj.doctorpatientplatform.entity.SpecialityType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DoctorRepository extends JpaRepository<Doctor, Long> {

    static List<Doctor> findByCityAndSpecialityType(String patientCity, SpecialityType type) {
        return null;
    }

    List<Doctor> findByCity(String city);

    List<Doctor> findByCityAndSpeciality(Speciality speciality);
}
