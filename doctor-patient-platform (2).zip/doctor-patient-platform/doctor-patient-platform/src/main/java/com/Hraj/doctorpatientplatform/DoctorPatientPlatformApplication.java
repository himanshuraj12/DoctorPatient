package com.Hraj.doctorpatientplatform;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;

@SpringBootApplication
@EntityScan("com.Hraj.doctorpatientplatform.entity")
public class DoctorPatientPlatformApplication {

    public static void main(String[] args) {
        SpringApplication.run(DoctorPatientPlatformApplication.class, args);
    }

}
