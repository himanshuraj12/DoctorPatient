package com.Hraj.doctorpatientplatform.service;

import com.Hraj.doctorpatientplatform.entity.Doctor;
import com.Hraj.doctorpatientplatform.entity.SpecialityType;
import com.Hraj.doctorpatientplatform.repository.DoctorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class PatientService {

    @Autowired
    private DoctorRepository doctorRepository;

    public List<Doctor> suggestDoctorsBySymptom(String symptom, String city) {
        // Map patient's symptom to corresponding doctor's speciality
        SpecialityType specialityType = mapSymptomToSpecialityType(symptom);

        // Retrieve doctors with the matching speciality in the patient's city
        List<Doctor> doctors = doctorRepository.findByCity(city)
                .stream()
                .filter(doctor -> doctor.getSpecialityEnum().equals(specialityType))
                .collect(Collectors.toList());

        return doctors;
    }

    private SpecialityType mapSymptomToSpecialityType(String symptom) {
        // Map patient's symptom to corresponding doctor's speciality
        switch (symptom.toLowerCase()) {
            case "arthritis":
            case "back pain":
            case "tissue injuries":
                return SpecialityType.ORTHOPEDIC;
            case "dysmenorrhea":
                return SpecialityType.GYNECOLOGY;
            case "skin infection":
            case "skin burn":
                return SpecialityType.DERMATOLOGY;
            case "ear pain":
                return SpecialityType.ENT_SPECIALIST;
            default:
                // If symptom is not recognized, return null
                return null;
        }
    }
}
