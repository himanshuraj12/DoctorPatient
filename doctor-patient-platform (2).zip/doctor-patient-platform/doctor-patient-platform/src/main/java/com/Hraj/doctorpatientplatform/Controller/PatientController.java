package com.Hraj.doctorpatientplatform.Controller;

import com.Hraj.doctorpatientplatform.entity.Doctor;
import com.Hraj.doctorpatientplatform.service.PatientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class PatientController {

    @Autowired
    private PatientService patientService;

    @GetMapping("/patients/suggest-doctors")
    public ResponseEntity<List<Doctor>> suggestDoctorsBySymptom(
            @RequestParam String symptom, @RequestParam String city) {
        List<Doctor> suggestedDoctors = patientService.suggestDoctorsBySymptom(symptom, city);
        return new ResponseEntity<>(suggestedDoctors, HttpStatus.OK);
    }
}
