package com.Hraj.doctorpatientplatform.entity;

public enum SpecialityType {
    ORTHOPEDIC, GYNECOLOGY, DERMATOLOGY, ORTHOPEDIC_INSTANCE, ENT_SPECIALIST

}
