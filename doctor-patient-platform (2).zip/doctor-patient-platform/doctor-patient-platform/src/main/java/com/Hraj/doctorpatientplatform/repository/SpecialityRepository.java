package com.Hraj.doctorpatientplatform.repository;

import com.Hraj.doctorpatientplatform.entity.Speciality;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SpecialityRepository extends JpaRepository<Speciality, Long> {
}