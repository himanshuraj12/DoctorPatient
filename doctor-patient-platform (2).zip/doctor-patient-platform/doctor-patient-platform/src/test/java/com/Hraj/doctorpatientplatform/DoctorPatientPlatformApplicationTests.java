package com.Hraj.doctorpatientplatform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DoctorPatientPlatformApplicationTests {

	@Test
	void contextLoads() {
	}

}
